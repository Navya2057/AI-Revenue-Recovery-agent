"""
build_dataset_from_kaggle.py
------------------------------
Builds Track-03 datasets from the REAL Kaggle "Credit Card Transactions"
dataset (transactions_data.csv + cards_data.csv + users_data.csv,
mcc_codes.json) instead of synthetic data.

Key idea: `errors` on a transaction is a REAL, gateway-reported decline
reason (Insufficient Balance, Bad PIN, Technical Glitch, Bad Card Number,
Bad CVV, Bad Expiration, Bad Zipcode) -- this is genuine "revenue at risk"
data, not something we invented.

For each failed transaction we look at the SAME card's very next
transaction (window function, no giant join): if it lands within 14 days
and succeeds, we call the failure "organically recovered". This gives a
REAL, data-grounded base recovery rate per error type / customer segment
-- which the recovery-likelihood model learns directly. Our own agent
layer (buckets, candidate actions, uplift assumptions, stopping rules) is
then applied on top, clearly separated from what the raw data tells us.

Outputs (schema-compatible with recovery_config.py / recovery_model.py /
policy_engine.py):
    data/customers.csv
    data/historical_recovery_outcomes.csv   (older 80% of failures, labelled)
    data/revenue_at_risk_events.csv         (most recent 20% -> "today's" batch)
"""

import duckdb
import pandas as pd
import numpy as np
from recovery_config import ACTIONS, ACTION_COST_INR

RAW = "data/kaggle_raw"

# Real decline-reason -> bucket mapping (documented, explainable rule)
ERROR_TO_BUCKET = {
    "Insufficient Balance": "SOFT",
    "Technical Glitch": "SOFT",
    "Bad PIN": "SOFT",              # user mistyped, safe to nudge & retry
    "Bad Zipcode": "HARD",          # verification / AVS mismatch, needs correction
    "Bad CVV": "HARD",              # needs card detail re-entry
    "Bad Expiration": "HARD",       # card expired, needs update
    "Bad Card Number": "HUMAN",     # possibly fraud/typo/lost card -> needs review
}
BUCKET_PRIORITY = {"HUMAN": 3, "HARD": 2, "SOFT": 1}  # if multiple errors, take the most severe


def pick_bucket(error_str: str) -> str:
    parts = [e.strip() for e in error_str.split(",") if e.strip()]
    buckets = [ERROR_TO_BUCKET.get(p, "HARD") for p in parts]
    if not buckets:
        return "SOFT"
    return max(buckets, key=lambda b: BUCKET_PRIORITY[b])


def main():
    con = duckdb.connect()
    print("Scanning transactions_data.csv with DuckDB (this streams, doesn't load 1.2GB into RAM)...")

    con.execute(f"""
        CREATE VIEW txn_raw AS
        SELECT
            id, date, client_id, card_id,
            CAST(replace(amount, '$', '') AS DOUBLE) AS amount,
            use_chip, merchant_id, merchant_city, merchant_state, mcc,
            NULLIF(TRIM(errors), '') AS errors
        FROM read_csv_auto('{RAW}/transactions_data.csv', SAMPLE_SIZE=200000)
    """)

    # Window function: for each card_id ordered by date, find the very next
    # transaction's date and error status -> "organic recovery" signal.
    con.execute("""
        CREATE VIEW txn_with_next AS
        SELECT
            *,
            LEAD(date)   OVER (PARTITION BY card_id ORDER BY date) AS next_date,
            LEAD(errors) OVER (PARTITION BY card_id ORDER BY date) AS next_errors
        FROM txn_raw
    """)

    failed = con.execute("""
        SELECT
            id AS event_id, date AS event_timestamp, client_id, card_id,
            amount AS amount_usd, use_chip, mcc, errors,
            next_date, next_errors,
            CASE
                WHEN next_date IS NOT NULL
                 AND next_date <= date + INTERVAL 14 DAY
                 AND (next_errors IS NULL) THEN 1
                ELSE 0
            END AS recovered
        FROM txn_with_next
        WHERE errors IS NOT NULL
        ORDER BY date
    """).fetchdf()

    print(f"Failed (revenue-at-risk) transactions found: {len(failed):,}")
    print(f"Organic recovery rate in raw data: {failed['recovered'].mean():.1%}")

    # --- bring in real user & card features ---
    users = con.execute(f"""
        SELECT id AS client_id,
               current_age, yearly_income, credit_score,
               CAST(replace(total_debt, '$', '') AS DOUBLE) AS total_debt,
               num_credit_cards
        FROM read_csv_auto('{RAW}/users_data.csv')
    """).fetchdf()
    users["yearly_income"] = users["yearly_income"].astype(str).str.replace("$", "", regex=False).astype(float)

    cards = con.execute(f"""
        SELECT id AS card_id, card_brand, card_type,
               CAST(replace(credit_limit, '$', '') AS DOUBLE) AS credit_limit,
               has_chip
        FROM read_csv_auto('{RAW}/cards_data.csv')
    """).fetchdf()

    failed = failed.merge(users, on="client_id", how="left").merge(cards, on="card_id", how="left")

    # amount: dataset is in USD (2010-2019 sample) -> convert to INR at an
    # approximate flat rate so amounts feel native for an India-focused pitch.
    INR_PER_USD = 83.0
    failed["amount_inr"] = (failed["amount_usd"].clip(lower=1) * INR_PER_USD).round(2)

    failed["bucket"] = failed["errors"].apply(pick_bucket)
    failed["event_timestamp"] = pd.to_datetime(failed["event_timestamp"])
    failed["hour_of_day"] = failed["event_timestamp"].dt.hour
    failed["day_of_week"] = failed["event_timestamp"].dt.weekday
    failed["days_overdue"] = 0  # this dataset is card-present POS/online, not B2B invoices

    # attempt_number: how many failures this SAME card has had in the current
    # dunning cycle -- a rolling 7-day window, not a lifetime cumulative count
    # (a lifetime count would make MAX_AUTOMATED_ATTEMPTS trip for almost every
    # card by year 9 of the dataset, which isn't what the stopping rule means).
    failed = failed.sort_values("event_timestamp").reset_index(drop=True)

    def rolling_count(g):
        s = g.set_index("event_timestamp")["event_id"]
        counts = s.groupby(s.index).transform("count")  # unused, placeholder
        return None

    counts = []
    for card_id, g in failed.groupby("card_id", sort=False):
        ts = g["event_timestamp"].values
        c = np.zeros(len(ts), dtype=int)
        window_start = 0
        for i in range(len(ts)):
            while ts[window_start] < ts[i] - np.timedelta64(7, "D"):
                window_start += 1
            c[i] = i - window_start + 1
        counts.append(pd.Series(c, index=g.index))
    failed["attempt_number"] = pd.concat(counts).reindex(failed.index).clip(upper=5)

    # customer-level derived features, matching the schema the rest of the
    # pipeline expects
    failed["customer_id"] = "CUST" + failed["client_id"].astype(str)
    failed["customer_tenure_months"] = np.clip(((failed["current_age"].fillna(35) - 18) * 3).astype(int), 3, 240)
    # a customer's own historical recovery rate (their track record), leaving out the current row
    cust_recovery = failed.groupby("customer_id")["recovered"].transform(
        lambda s: s.expanding().mean().shift(1)
    )
    failed["customer_past_recovery_rate"] = cust_recovery.fillna(failed["recovered"].mean()).round(3)

    income = failed["yearly_income"].fillna(failed["yearly_income"].median())
    failed["customer_segment"] = pd.cut(
        income, bins=[-1, 30000, 60000, 120000, np.inf],
        labels=["low_income", "mid_income", "upper_mid_income", "high_income"]
    ).astype(str)

    failed["gateway"] = failed["use_chip"].map({
        "Chip Transaction": "Card-Chip", "Swipe Transaction": "Card-Swipe",
        "Online Transaction": "Card-Online"
    }).fillna("Card-Other")
    failed["preferred_channel"] = np.where(
        failed["gateway"].eq("Card-Online"), "Email", "SMS"
    )

    # root_cause_label: the real, gateway-reported reason (kept human-readable)
    failed["root_cause_label"] = failed["errors"]
    failed["event_type"] = "payment_failure"

    keep_cols = [
        "event_id", "customer_id", "customer_segment", "event_type",
        "root_cause_label", "bucket", "amount_inr", "gateway", "days_overdue",
        "event_timestamp", "hour_of_day", "day_of_week", "attempt_number",
        "customer_tenure_months", "customer_past_recovery_rate",
        "preferred_channel", "recovered",
    ]
    final = failed[keep_cols].copy()

    # Time-based split: last 30 days of real data = "today's" live batch the
    # agent must act on right now. Everything before that = historical
    # training log (this is how a real deployment would be bootstrapped).
    max_date = final["event_timestamp"].max()
    cutoff = max_date - pd.Timedelta(days=30)
    historical = final[final["event_timestamp"] < cutoff].copy()
    current_batch = final[final["event_timestamp"] >= cutoff].copy()

    # historical needs an action_taken + action_cost to train the recovery
    # model (real data has no logged "action", so we sample a plausible
    # historical action per bucket -- documented assumption, see README)
    rng = np.random.default_rng(7)
    def sample_action(bucket):
        return rng.choice(ACTIONS[bucket])
    historical["action_taken"] = historical["bucket"].apply(sample_action)
    historical["action_cost_inr"] = historical["action_taken"].map(ACTION_COST_INR)

    historical.drop(columns=["recovered"]).assign(recovered=historical["recovered"]).to_csv(
        "data/historical_recovery_outcomes.csv", index=False
    )
    current_batch.drop(columns=["recovered"]).to_csv("data/revenue_at_risk_events.csv", index=False)

    # customer master (for reference / display)
    cust_master = final.groupby("customer_id").agg(
        customer_segment=("customer_segment", "first"),
        customer_tenure_months=("customer_tenure_months", "first"),
        customer_past_recovery_rate=("customer_past_recovery_rate", "last"),
        preferred_channel=("preferred_channel", "first"),
    ).reset_index()
    cust_master.to_csv("data/customers.csv", index=False)

    print(f"\nWrote data/historical_recovery_outcomes.csv  ({len(historical):,} rows, real historical recovery={historical['recovered'].mean():.1%})")
    print(f"Wrote data/revenue_at_risk_events.csv        ({len(current_batch):,} rows -> today's live batch)")
    print(f"Wrote data/customers.csv                     ({len(cust_master):,} unique customers)")
    print(f"\nTotal amount at risk in today's batch: Rs.{current_batch['amount_inr'].sum():,.0f}")
    print("\nBucket mix in today's batch:")
    print(current_batch["bucket"].value_counts())
    print("\nRoot cause (real gateway error) mix in today's batch:")
    print(current_batch["root_cause_label"].value_counts())


if __name__ == "__main__":
    main()
