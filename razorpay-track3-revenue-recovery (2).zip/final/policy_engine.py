"""
policy_engine.py
------------------
Turns (event + real risk score from recovery_model.py) into ONE bounded,
explainable action per event, respecting stopping rules / compliance:

  - MAX_AUTOMATED_ATTEMPTS: after N prior failures on the same card, must
    escalate to a human path or stop (no infinite retry loops).
  - NO_CONTACT_HOURS: no SMS/WhatsApp/call nudges 9pm-8am (DND compliance).
  - MIN_EXPECTED_VALUE_TO_ACT: if expected extra recovered amount minus
    action cost is below this, don't act -- flag for review instead of
    spending contact budget / eroding customer goodwill on transactions
    that were already ~certain to self-recover.

Expected value of taking `action` on an event:
    p_base      = model's REAL predicted probability of organic recovery
    p_with_act  = min(0.97, p_base + ACTION_UPLIFT_PP[action])   <- documented assumption
    incremental_value = (p_with_act - p_base) * amount - action_cost

We rank candidate actions by INCREMENTAL value (what an intervention
actually adds), not raw expected recovered amount, so "do nothing" is
correctly preferred whenever the real risk score already says a
transaction is very likely to self-resolve.

Produces one row per event: chosen action, real risk score, assumed
uplift used, incremental expected value, and a plain-English reason
-> the audit trail required by the buildathon bar.
"""

import pandas as pd
import numpy as np
from recovery_config import (
    ACTIONS, ACTION_COST_INR, ACTION_EXPLANATION, ACTION_UPLIFT_PP,
    MAX_AUTOMATED_ATTEMPTS, NO_CONTACT_HOURS, MIN_EXPECTED_VALUE_TO_ACT,
)
from recovery_model import RecoveryLikelihoodModel

CONTACT_ACTIONS = {
    "nudge_sms", "nudge_upi_intent", "send_update_link_sms",
    "send_update_link_whatsapp", "agentic_call_offer_plan",
}


def decide_actions(events: pd.DataFrame, model: RecoveryLikelihoodModel) -> pd.DataFrame:
    p_base_all = model.predict_recovery_proba(events)
    events = events.copy()
    events["p_organic_recovery"] = p_base_all

    decisions = []
    for (_, ev), p_base in zip(events.iterrows(), p_base_all):
        bucket = ev["bucket"]
        candidates = list(ACTIONS[bucket]) + ["hold_no_action"]

        forced_stop_reason = None
        if ev["attempt_number"] > MAX_AUTOMATED_ATTEMPTS and bucket != "HUMAN":
            candidates = ["human_escalation", "hold_no_action"]
            forced_stop_reason = (f"attempt_number={ev['attempt_number']} exceeds "
                                   f"MAX_AUTOMATED_ATTEMPTS={MAX_AUTOMATED_ATTEMPTS} -> escalate, stop auto-retrying")

        if ev["hour_of_day"] in NO_CONTACT_HOURS:
            non_contact = [a for a in candidates if a not in CONTACT_ACTIONS]
            if non_contact:
                candidates = non_contact

        best_action, best_incremental, best_p_with_act = "hold_no_action", 0.0, p_base
        for action in candidates:
            if action == "hold_no_action":
                incremental, p_with_act = 0.0, p_base
            else:
                uplift = ACTION_UPLIFT_PP.get(action, 0.0)
                p_with_act = min(0.97, p_base + uplift)
                cost = ACTION_COST_INR.get(action, 0.0)
                incremental = (p_with_act - p_base) * ev["amount_inr"] - cost
            if incremental > best_incremental:
                best_action, best_incremental, best_p_with_act = action, incremental, p_with_act

        if forced_stop_reason:
            reason = forced_stop_reason
        elif best_action == "hold_no_action":
            reason = (f"Real risk score says {p_base:.0%} likely to self-recover; no candidate "
                      f"action clears the Rs.{MIN_EXPECTED_VALUE_TO_ACT:.0f} incremental-value bar -> hold")
        else:
            reason = ACTION_EXPLANATION.get(best_action, "")

        if best_incremental < MIN_EXPECTED_VALUE_TO_ACT and forced_stop_reason is None:
            best_action = "write_off_review" if (bucket == "HUMAN" and p_base < 0.5) else "hold_no_action"
            best_p_with_act = p_base
            best_incremental = 0.0

        decisions.append({
            "event_id": ev["event_id"], "customer_id": ev["customer_id"],
            "event_type": ev["event_type"], "root_cause_label": ev["root_cause_label"],
            "bucket": bucket, "amount_inr": ev["amount_inr"],
            "attempt_number": ev["attempt_number"], "hour_of_day": ev["hour_of_day"],
            "p_organic_recovery": round(float(p_base), 3),
            "chosen_action": best_action,
            "p_with_action": round(float(best_p_with_act), 3),
            "action_cost_inr": float(ACTION_COST_INR.get(best_action, 0.0)),
            "incremental_expected_value_inr": round(float(best_incremental), 2),
            "reason": reason,
        })

    return pd.DataFrame(decisions)


if __name__ == "__main__":
    hist = pd.read_csv("data/historical_recovery_outcomes.csv")
    events = pd.read_csv("data/revenue_at_risk_events.csv")

    model = RecoveryLikelihoodModel()
    metrics = model.fit(hist)
    print(f"[risk model] ROC-AUC={metrics['roc_auc']:.3f}  "
          f"riskiest-15% recall={metrics['recall_at_risk_slice']:.3f}  "
          f"riskiest-15% precision={metrics['precision_at_risk_slice']:.3f}")

    decisions = decide_actions(events, model)
    decisions.to_csv("data/recovery_decisions_audit_trail.csv", index=False)

    print(f"\nDecided actions for {len(decisions):,} events.")
    print("\nAction mix:")
    print(decisions["chosen_action"].value_counts())
    print(f"\nTotal amount at risk (batch)     : Rs.{events['amount_inr'].sum():,.0f}")
    print(f"Baseline expected organic recovery: Rs.{(events['amount_inr'] * decisions['p_organic_recovery']).sum():,.0f}")
    print(f"Extra expected recovery from agent: Rs.{decisions['incremental_expected_value_inr'].clip(lower=0).sum():,.0f}")
    print(f"Total action cost                 : Rs.{decisions['action_cost_inr'].sum():,.0f}")
    print("\nWrote data/recovery_decisions_audit_trail.csv")
