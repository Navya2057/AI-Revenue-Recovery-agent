"""
recovery_model.py
-------------------
The genuine ML component, trained on REAL data: predicts P(organic
recovery) for a failed transaction -- i.e. how likely this specific
failure is to resolve itself if we do NOTHING, based on the event, the
customer, and the card.

IMPORTANT, honestly stated limitation: the raw Kaggle transactions dataset
is a POS/online transaction log, not a merchant's dunning/recovery-ops
log -- it does not record which recovery ACTION (if any) was attempted
on a failure, so we cannot learn a true causal "does action X increase
recovery" effect from this data. What we CAN learn honestly, and do
learn here, is a risk score: which failures are unlikely to self-resolve
and therefore deserve an intervention at all. The policy engine
(policy_engine.py) then applies DOCUMENTED, clearly-labeled action-uplift
assumptions on top of this real risk score, flagged as assumptions a live
deployment would replace with real numbers from A/B-testing the actions
once they go live.

Calibration note: the true base rate is ~95% recovered -- a strongly
imbalanced problem. We deliberately train WITHOUT class-weight balancing
so predict_proba stays well-calibrated to real probabilities (needed for
Rupee-accurate expected-value math downstream); class-balancing would
distort the probabilities even though it can raise minority-class recall.
Because plain accuracy is meaningless here, we evaluate with metrics that
suit a RANKING/scoring problem: ROC-AUC, and precision/recall achieved
when we flag the riskiest 15% of transactions by predicted score (the
same slice size the policy engine ends up intervening on).
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import roc_auc_score, precision_score, recall_score, f1_score

NUM_COLS = ["amount_inr", "days_overdue", "hour_of_day", "day_of_week",
            "attempt_number", "customer_tenure_months", "customer_past_recovery_rate"]
CAT_COLS = ["event_type", "bucket", "gateway", "preferred_channel", "customer_segment"]


class RecoveryLikelihoodModel:
    def __init__(self):
        # No class_weight here on purpose -- keeps predict_proba calibrated
        # to real probabilities, which the policy engine needs for Rupee math.
        self.model = HistGradientBoostingClassifier(
            max_iter=300, max_depth=6, learning_rate=0.05, random_state=42
        )
        self.cat_encoders = {c: LabelEncoder() for c in CAT_COLS}
        self.feature_names_ = NUM_COLS + CAT_COLS

    def _build_X(self, df: pd.DataFrame, fit: bool) -> pd.DataFrame:
        X = df[NUM_COLS].copy()
        for c in CAT_COLS:
            if fit:
                X[c] = self.cat_encoders[c].fit_transform(df[c].astype(str))
            else:
                known = set(self.cat_encoders[c].classes_)
                safe = df[c].astype(str).apply(lambda v: v if v in known else self.cat_encoders[c].classes_[0])
                X[c] = self.cat_encoders[c].transform(safe)
        return X[self.feature_names_]

    def fit(self, hist_df: pd.DataFrame, test_size: float = 0.25, risk_slice: float = 0.15) -> dict:
        y = hist_df["recovered"].astype(int).values
        X = self._build_X(hist_df, fit=True)
        idx_train, idx_test = train_test_split(
            hist_df.index, test_size=test_size, random_state=42, stratify=y
        )
        X_train, X_test = X.loc[idx_train], X.loc[idx_test]
        y_train, y_test = y[hist_df.index.get_indexer(idx_train)], y[hist_df.index.get_indexer(idx_test)]

        self.model.fit(X_train, y_train)
        proba = self.model.predict_proba(X_test)[:, 1]

        # Flag the riskiest `risk_slice` of the test batch (lowest predicted
        # recovery probability) and score against the true minority class --
        # this maps directly to what the policy engine does with real events.
        n_flag = max(1, int(len(proba) * risk_slice))
        risk_order = np.argsort(proba)  # ascending: lowest recovery prob first
        flagged_mask = np.zeros(len(proba), dtype=bool)
        flagged_mask[risk_order[:n_flag]] = True
        y_not_recovered = 1 - y_test  # 1 = "did not recover" = the class we want to catch

        metrics = {
            "n_test": len(y_test),
            "positive_class_rate": float(y_train.mean()),
            "roc_auc": roc_auc_score(y_test, proba),
            "risk_slice_pct": risk_slice,
            "precision_at_risk_slice": precision_score(y_not_recovered, flagged_mask, zero_division=0),
            "recall_at_risk_slice": recall_score(y_not_recovered, flagged_mask, zero_division=0),
            "f1_at_risk_slice": f1_score(y_not_recovered, flagged_mask, zero_division=0),
            "mean_predicted_recovery_rate": float(proba.mean()),
            "true_recovery_rate_test": float(y_test.mean()),
        }
        return metrics

    def predict_recovery_proba(self, df_rows: pd.DataFrame) -> np.ndarray:
        """P(this failure organically recovers with NO intervention)."""
        X = self._build_X(df_rows, fit=False)
        return self.model.predict_proba(X)[:, 1]


if __name__ == "__main__":
    hist = pd.read_csv("data/historical_recovery_outcomes.csv")
    model = RecoveryLikelihoodModel()
    m = model.fit(hist)
    print("Recovery-likelihood (risk) model -- held-out test set:")
    print(f"  n_test                       : {m['n_test']:,}")
    print(f"  True recovery rate (test)    : {m['true_recovery_rate_test']:.1%}")
    print(f"  Mean predicted recovery rate : {m['mean_predicted_recovery_rate']:.1%}  <- calibration check, should track the line above")
    print(f"  ROC-AUC                      : {m['roc_auc']:.3f}")
    print(f"  Riskiest {m['risk_slice_pct']:.0%} slice precision (true non-recoverers caught): {m['precision_at_risk_slice']:.3f}")
    print(f"  Riskiest {m['risk_slice_pct']:.0%} slice recall                                : {m['recall_at_risk_slice']:.3f}")
