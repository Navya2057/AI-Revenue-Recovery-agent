"""
generate_messages_for_batch.py
---------------------------------
Runs hinglish_recovery_message.py over the policy engine's actual output:
for every event where the agent chose "agentic_call_offer_plan", draft a
real Hinglish message. This is the piece that turns "the agent decided to
call this customer" into "here is what it would actually say."

Run AFTER policy_engine.py (needs data/recovery_decisions_audit_trail.csv).

Usage:
    export GEMINI_API_KEY="your-key"   # optional -- falls back to a safe template without it
    python3 generate_messages_for_batch.py
"""

import pandas as pd
from hinglish_recovery_message import draft_recovery_message

if __name__ == "__main__":
    decisions = pd.read_csv("data/recovery_decisions_audit_trail.csv")
    events = pd.read_csv("data/revenue_at_risk_events.csv")

    targets = decisions[decisions["chosen_action"] == "agentic_call_offer_plan"].merge(
        events[["event_id", "customer_segment", "days_overdue"]], on="event_id", how="left"
    )

    if targets.empty:
        print("No events in this batch were routed to agentic_call_offer_plan -- nothing to draft.")
        print("(Try a batch where the HUMAN bucket has more high-value ambiguous cases.)")
    else:
        print(f"Drafting messages for {len(targets)} events...\n")
        rows = []
        for _, t in targets.iterrows():
            msg = draft_recovery_message(
                amount_inr=t["amount_inr"],
                root_cause=t["root_cause_label"],
                customer_segment=t.get("customer_segment", ""),
                days_overdue=t.get("days_overdue", 0),
            )
            rows.append({"event_id": t["event_id"], "customer_id": t["customer_id"],
                         "amount_inr": t["amount_inr"], "drafted_message": msg})
            print(f"[{t['event_id']}] Rs.{t['amount_inr']:,.0f} -- {msg}\n")

        pd.DataFrame(rows).to_csv("data/drafted_recovery_messages.csv", index=False)
        print("Wrote data/drafted_recovery_messages.csv")
