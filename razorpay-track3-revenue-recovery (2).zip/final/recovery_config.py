"""
recovery_config.py
--------------------
Single source of truth for: root-cause -> bucket mapping, candidate recovery
actions per bucket, per-action cost, and the HIDDEN ground-truth outcome
simulator (stands in for "what would really happen" -- the recovery model
never sees this function directly, only noisy historical outcomes sampled
from it, exactly like a real ML system learning from past logs).
"""

import numpy as np

CAUSE_TO_BUCKET = {
    "insufficient_funds": "SOFT", "bank_server_timeout": "SOFT",
    "wrong_otp_auth_fail": "SOFT", "daily_limit_exceeded": "SOFT",
    "otp_delay_dropoff": "SOFT", "app_crash_or_timeout": "SOFT",
    "cashflow_delay_buyer_side": "SOFT",
    "card_expired": "HARD", "mandate_not_registered": "HARD",
    "bank_declined_mandate": "HARD", "payment_method_unavailable": "HARD",
    "invoice_not_received": "HARD",
    "risk_engine_block": "HUMAN", "customer_revoked_mandate": "HUMAN",
    "high_shipping_or_fees_surprise": "HUMAN", "price_comparison_exit": "HUMAN",
    "invoice_dispute": "HUMAN", "approval_pending_buyer_org": "HUMAN",
    "genuine_non_payment_risk": "HUMAN",
}

ACTIONS = {
    "SOFT": ["auto_retry_now", "auto_retry_off_peak", "nudge_sms", "nudge_upi_intent"],
    "HARD": ["send_update_link_sms", "send_update_link_whatsapp", "send_update_link_email"],
    "HUMAN": ["agentic_call_offer_plan", "human_escalation", "write_off_review"],
}

ACTION_COST_INR = {
    "auto_retry_now": 0.5, "auto_retry_off_peak": 0.5, "nudge_sms": 1.5, "nudge_upi_intent": 1.0,
    "send_update_link_sms": 1.5, "send_update_link_whatsapp": 2.0, "send_update_link_email": 0.5,
    "agentic_call_offer_plan": 15.0, "human_escalation": 60.0, "write_off_review": 5.0,
}

# Human-readable, one-line justification shown in the audit trail
ACTION_EXPLANATION = {
    "auto_retry_now": "Transient/soft decline -> safe to auto-retry immediately",
    "auto_retry_off_peak": "Soft decline + funds likely to land later -> retry at a better time window",
    "nudge_sms": "Soft decline -> lightweight SMS nudge to complete payment",
    "nudge_upi_intent": "Soft decline, UPI-preferring customer -> resend UPI intent link",
    "send_update_link_sms": "Hard decline (e.g. expired card/mandate) -> needs customer action, SMS link",
    "send_update_link_whatsapp": "Hard decline, WhatsApp-preferring customer -> update-details link on WhatsApp",
    "send_update_link_email": "Hard decline, low-cost fallback channel -> email update link",
    "agentic_call_offer_plan": "Ambiguous/high-value case -> AI voice agent offers a payment plan",
    "human_escalation": "High ambiguity or high value -> route to a human agent",
    "write_off_review": "Very low expected recovery vs cost -> flag for manual write-off review, do not keep chasing",
}

# Compliance / stopping-rule constants
MAX_AUTOMATED_ATTEMPTS = 3     # after this, must escalate to human or stop (no infinite retries)
NO_CONTACT_HOURS = set(range(21, 24)) | set(range(0, 8))  # 9pm-8am: no calls/SMS nudges (DND compliance)
MIN_EXPECTED_VALUE_TO_ACT = 2.0  # INR; below this, expected recovery doesn't justify any action cost


def base_success_prob(bucket, action, days_overdue, past_rate, attempt_number, hour_of_day):
    """HIDDEN ground truth used only by the simulator to decide what actually
    happens when `action` is executed. Not visible to the recovery model."""
    base = {"SOFT": 0.55, "HARD": 0.38, "HUMAN": 0.22}[bucket]
    right_action_bonus = {
        ("SOFT", "auto_retry_off_peak"): 0.12, ("SOFT", "auto_retry_now"): 0.04,
        ("SOFT", "nudge_upi_intent"): 0.10, ("SOFT", "nudge_sms"): 0.05,
        ("HARD", "send_update_link_whatsapp"): 0.14, ("HARD", "send_update_link_sms"): 0.08,
        ("HARD", "send_update_link_email"): 0.03,
        ("HUMAN", "agentic_call_offer_plan"): 0.18, ("HUMAN", "human_escalation"): 0.10,
        ("HUMAN", "write_off_review"): 0.0,
    }.get((bucket, action), 0.0)
    p = base + right_action_bonus
    p += (past_rate - 0.5) * 0.35
    p -= min(days_overdue, 90) / 90 * 0.20
    p -= max(0, attempt_number - 1) * 0.08
    if 9 <= hour_of_day <= 21:
        p += 0.05
    return float(np.clip(p, 0.02, 0.93))


# ---------------------------------------------------------------------------
# Action-uplift ASSUMPTIONS (documented, not learned)
# ---------------------------------------------------------------------------
# The real Kaggle transaction log has no record of which recovery action was
# ever attempted, so there is no causal "action -> outcome" signal to learn
# from raw POS data. These uplift multipliers are a standard, published
# industry-range assumption (Recurly / Churnkey 2025-26 dunning-playbook
# figures: soft nudges lift recovery ~10-20pp, hard-decline update links
# ~20-35pp given the customer engages, human/agentic escalation on ambiguous
# cases ~15-30pp) -- clearly separated from the REAL risk score the model
# learns. In a live deployment these would be replaced within weeks by
# measured numbers from A/B-testing the actions themselves.
ACTION_UPLIFT_PP = {
    "auto_retry_now": 0.06, "auto_retry_off_peak": 0.12,
    "nudge_sms": 0.10, "nudge_upi_intent": 0.14,
    "send_update_link_sms": 0.20, "send_update_link_whatsapp": 0.28,
    "send_update_link_email": 0.12,
    "agentic_call_offer_plan": 0.30, "human_escalation": 0.18,
    "write_off_review": 0.0,
}
