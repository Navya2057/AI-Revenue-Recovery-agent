"""
hinglish_recovery_message.py
------------------------------
Wires the policy engine's `agentic_call_offer_plan` action to a real Gemini
call: given a customer + event's details, drafts a short, warm, Hinglish
payment-plan offer message -- exactly the "Hinglish voice recovery" example
direction Track 03's brief calls out.

This turns the agent from "decides what to do" into "actually does it":
policy_engine.py already tells you WHICH events get this action; this module
generates the WORDS for those events.

Setup:
    pip install google-genai
    export GEMINI_API_KEY="your-key-here"   # get one at https://aistudio.google.com/apikey

Usage:
    from hinglish_recovery_message import draft_recovery_message
    msg = draft_recovery_message(
        amount_inr=1850, root_cause="Insufficient Balance",
        customer_segment="mid_income", days_overdue=0,
    )
    print(msg)
"""

import os
from google import genai

MODEL = "gemini-2.5-flash"  # fast + cheap, good enough for short templated drafts

_SYSTEM_INSTRUCTION = """You are a payment recovery assistant for an Indian fintech.
Write ONE short message (2-3 sentences max) in natural Hinglish (Hindi+English mix,
Roman/Latin script) to a customer whose payment failed, offering help to complete it.

Rules:
- Warm, respectful, never pushy or shaming.
- Never mention internal terms like "risk score", "bucket", or "root cause label".
- If the amount is large or the case is ambiguous, offer a callback / flexible
  payment plan rather than demanding immediate payment.
- End with one clear, low-friction next step (a link, a reply, or a callback slot).
- Do not use emojis. Do not exceed 3 sentences.
"""


def draft_recovery_message(
    amount_inr: float,
    root_cause: str,
    customer_segment: str = "",
    days_overdue: int = 0,
    api_key: str | None = None,
) -> str:
    """Returns a short Hinglish recovery message for one failed-payment event.

    Falls back to a safe template (no API call) if no key is configured, so
    the rest of the pipeline never breaks just because this piece isn't wired
    up yet -- useful while you're still setting up the API key.
    """
    key = api_key or os.environ.get("GEMINI_API_KEY")
    if not key:
        return _fallback_template(amount_inr, root_cause, days_overdue)

    client = genai.Client(api_key=key)
    context = (
        f"Failed payment amount: Rs.{amount_inr:,.0f}. "
        f"Reason: {root_cause}. "
        f"Customer segment: {customer_segment or 'unknown'}. "
        f"Days overdue: {days_overdue}."
    )
    response = client.models.generate_content(
        model=MODEL,
        contents=context,
        config={"system_instruction": _SYSTEM_INSTRUCTION, "temperature": 0.6},
    )
    return response.text.strip()


def _fallback_template(amount_inr: float, root_cause: str, days_overdue: int) -> str:
    if days_overdue > 0:
        return (
            f"Hi! Aapka Rs.{amount_inr:,.0f} ka payment abhi pending hai "
            f"({days_overdue} din se). Koi dikkat ho to hume batayein -- "
            f"hum ek convenient payment plan bhi set up kar sakte hain. "
            f"Reply karke batayein kya theek rahega."
        )
    return (
        f"Hi! Aapka Rs.{amount_inr:,.0f} ka payment complete nahi ho paya "
        f"({root_cause}). Koi baat nahi, aap yahan se dobara try kar sakte "
        f"hain -- link kuch der mein bhej rahe hain."
    )


if __name__ == "__main__":
    # Quick manual test -- works even without an API key (uses the fallback).
    sample = draft_recovery_message(
        amount_inr=18500, root_cause="Bad Card Number",
        customer_segment="upper_mid_income", days_overdue=0,
    )
    print("Sample message:\n", sample)
