"""
simulate_batch.py
--------------------
Runs a stochastic simulation of ACTUAL outcomes (not just expected value)
for today's live batch, under three policies, so we can report a single
concrete "money recovered" number for each -- exactly what the buildathon
bar asks for ("Show measured money recovered across a batch").

Policies compared:
  1. do_nothing      -> baseline, nobody is contacted, only organic recovery happens
  2. blind_retry_all -> naive baseline many teams ship: retry/nudge every
                         single failure the same way, ignoring bucket/cost
  3. agent_policy     -> this project's bounded, risk-scored, cost-aware policy

Uses the SAME documented uplift assumptions as the policy engine (see
recovery_config.ACTION_UPLIFT_PP) to sample a realised outcome per event,
with a fixed random seed for reproducibility. Also enforces the compliance
stopping rules (NO_CONTACT_HOURS, MAX_AUTOMATED_ATTEMPTS) even for the
naive baseline, since those are hard compliance constraints, not policy
choices.
"""

import numpy as np
import pandas as pd
from recovery_config import (
    ACTIONS, ACTION_COST_INR, ACTION_UPLIFT_PP, NO_CONTACT_HOURS,
    MAX_AUTOMATED_ATTEMPTS,
)
from recovery_model import RecoveryLikelihoodModel
from policy_engine import decide_actions, CONTACT_ACTIONS

RNG = np.random.default_rng(2026)


def simulate(events: pd.DataFrame, p_base: np.ndarray, action_per_event: pd.Series) -> dict:
    amounts = events["amount_inr"].values
    total_at_risk = amounts.sum()

    p_final = p_base.copy()
    total_cost = 0.0
    for i, action in enumerate(action_per_event.values):
        if action in ("hold_no_action", "write_off_review", None):
            continue
        uplift = ACTION_UPLIFT_PP.get(action, 0.0)
        p_final[i] = min(0.97, p_base[i] + uplift)
        total_cost += ACTION_COST_INR.get(action, 0.0)

    draws = RNG.random(len(events))
    recovered_mask = draws < p_final
    recovered_amount = amounts[recovered_mask].sum()

    return {
        "total_at_risk": float(total_at_risk),
        "recovered_amount": float(recovered_amount),
        "recovery_rate": float(recovered_mask.mean()),
        "action_cost": float(total_cost),
        "net_value": float(recovered_amount - total_cost),
    }


def naive_action(bucket: str, hour: int, attempt: int) -> str:
    """Blind baseline: always try the single 'obvious' action for the
    bucket, ignoring cost-effectiveness, ignoring risk score -- still
    respects hard compliance limits (DND hours, max attempts) because
    those are legal/policy constraints, not optimisation choices."""
    if attempt > MAX_AUTOMATED_ATTEMPTS:
        return "human_escalation"
    default = {"SOFT": "auto_retry_now", "HARD": "send_update_link_sms",
               "HUMAN": "human_escalation"}[bucket]
    if hour in NO_CONTACT_HOURS and default in CONTACT_ACTIONS:
        return None  # skip this cycle, no non-contact fallback in the naive policy
    return default


if __name__ == "__main__":
    hist = pd.read_csv("data/historical_recovery_outcomes.csv")
    events = pd.read_csv("data/revenue_at_risk_events.csv")

    model = RecoveryLikelihoodModel()
    model.fit(hist)
    p_base = model.predict_recovery_proba(events)

    # Policy 1: do nothing
    do_nothing_actions = pd.Series(["hold_no_action"] * len(events))

    # Policy 2: blind retry / nudge everyone the same way
    blind_actions = pd.Series([
        naive_action(row.bucket, row.hour_of_day, row.attempt_number)
        for row in events.itertuples()
    ])

    # Policy 3: this project's agent
    decisions = decide_actions(events, model)
    agent_actions = decisions["chosen_action"]

    results = {}
    for name, actions in [("do_nothing", do_nothing_actions),
                           ("blind_retry_all", blind_actions),
                           ("agent_policy", agent_actions)]:
        results[name] = simulate(events, p_base.copy(), actions)

    print(f"{'Policy':<18}{'Recovered (Rs.)':>18}{'Recovery %':>13}{'Cost (Rs.)':>13}{'Net value (Rs.)':>18}")
    for name, r in results.items():
        print(f"{name:<18}{r['recovered_amount']:>18,.0f}{r['recovery_rate']:>12.1%}{r['action_cost']:>13,.0f}{r['net_value']:>18,.0f}")

    lift_vs_nothing = results["agent_policy"]["net_value"] - results["do_nothing"]["net_value"]
    lift_vs_blind = results["agent_policy"]["net_value"] - results["blind_retry_all"]["net_value"]
    print(f"\nAgent policy net-value lift vs do-nothing      : Rs.{lift_vs_nothing:,.0f}")
    print(f"Agent policy net-value lift vs blind-retry-all : Rs.{lift_vs_blind:,.0f}")

    pd.DataFrame(results).T.to_csv("data/simulation_results.csv")
    print("\nWrote data/simulation_results.csv")
